package com.example.amitoz.locationreminder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import static java.lang.Math.atan2;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.Math.toRadians;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapLongClickListener {

    private GoogleMap mMap;
    LocationManager locationManager;
    LocationListener locationListener;
    LatLng markerLocation;
    Boolean pressed;
    EditText radius;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults.length > 0) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        pressed = false;
        radius = (EditText) findViewById(R.id.editText);
    }


    public double getDistanceFromLatLonInM(double lat, double lon, double ntnuLat, double ntnuLon) {
        double R = 6371000;
        double dLat = toRadians(ntnuLat - lat);
        double dLon = toRadians(ntnuLon - lon);
        double a = sin(dLat / 2) * sin(dLat / 2) +
                cos(toRadians(lat)) * cos(toRadians(ntnuLat)) *
                        sin(dLon / 2) * sin(dLon / 2);
        double c = 2 * atan2(sqrt(a), sqrt(1 - a));
        double d = R * c;
        return d;
    }

    public void alarmReminder() {
        MediaPlayer mplayer = MediaPlayer.create(this, R.raw.air);
        mplayer.start();


    }
    //Allow us to do something when the map is ready
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapLongClickListener(this);
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (pressed == true) {
                    double dist = getDistanceFromLatLonInM(location.getLatitude(), location.getLongitude(), markerLocation.latitude, markerLocation.longitude);

                    if (dist < Double.parseDouble(radius.getText().toString())) {
                        alarmReminder();
                        Log.i("Indistance", Double.toString(dist));
                        //Toast.makeText(getApplicationContext(), "Test", Toast.LENGTH_SHORT).show();

                    } else {
                        Log.i("distance", Double.toString(dist));
                        //Toast.makeText(getApplicationContext(), "Test2", Toast.LENGTH_SHORT).show();
                    }
                }
                LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(userLocation));

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        if (Build.VERSION.SDK_INT < 23) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                Location lastknownlocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                LatLng userLocation = new LatLng(lastknownlocation.getLatitude(), lastknownlocation.getLongitude());
                mMap.addMarker(new MarkerOptions().position(userLocation).title("Ur location"));

                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 10));


            }
        }




    }

    @Override
    public void onMapLongClick(LatLng latLng) {
        pressed = true;
        markerLocation = latLng;
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(latLng).title("Target"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
        Toast.makeText(getApplicationContext(), "Reminder is Set!", Toast.LENGTH_LONG).show();


    }
}
